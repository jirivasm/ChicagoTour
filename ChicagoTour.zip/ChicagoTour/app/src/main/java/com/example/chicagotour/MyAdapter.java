package com.example.chicagotour;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

public class MyAdapter extends FragmentPagerAdapter {

    public MyAdapter(@NonNull FragmentManager fm, int behavior) {
        super(fm, behavior);
    }

    public MyAdapter(FragmentManager fm) {
        super(fm);
    }

    @NonNull
    @Override
    public Fragment getItem(int position) {
        if (position == 0) {
            return new NightLifeFragment();
        } else if (position == 1) {
            return new RestaurantsFragments();
        } else if (position == 2) {
            return new ParksFragment();
        } else {
            return new TouristPlacesFragments();
        }
    }

    @Override
    public int getCount() {
        return 4;
    }

    @Nullable
    @Override
    public CharSequence getPageTitle(int position) {
        return super.getPageTitle(position);
    }
}
