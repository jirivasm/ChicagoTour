package com.example.chicagotour;

public class Place {

    private String mName;

    Place(String name) {
        name = "";
    }

    public String getName(){
        return mName;
    }
    public void setName(String newName)
    {
        mName = newName;
    }

}
